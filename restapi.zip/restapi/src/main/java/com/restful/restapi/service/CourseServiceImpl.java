package com.restful.restapi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.restful.restapi.dao.CourseDao;
import com.restful.restapi.entity.Course;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseDao coursedao;
	
	//List<Course> list;
	public CourseServiceImpl() {
		/*list = new ArrayList<Course>(); 
		list.add(new Course(1 , "Maths" , "Maths is good"));
		list.add(new Course(2 , "Science" , "Science is good"));
		list.add(new Course(3 , "Eng" , "Eng is good"));
		list.add(new Course(4 , "Social" , "Social is good"));*/
		
	}
//all courses
	public List<Course> getCourses() {
		// TODO Auto-generated method stub
		return coursedao.findAll();
	}

	//get one course by id
	@Override
	public Course getCourseid(Integer courseId) {
		/*
		Course c = null;
		for(Course course:list) {
			if(course.getId()==courseId) {
				c = course;
				break; 
			}
		}*/
	
		return coursedao.getOne(courseId);
	}
	
	//add new course
	@Override
	public Course addCourse(Course course) {
		//list.add(course);
		coursedao.save(course);
		
		return course;
	}
	
	//update course
	
	@Override
	public Course updateCourse(Course course) {
		/*list.forEach(e ->{
			if(e.getId()==course.getId()) {
				e.setTitle(course.getTitle());
				e.setDescription(course.getDescription());
			}
		});*/
		coursedao.save(course);
		return course;
	}
	//delete course
	@Override
	public void deleteCourse(Integer courseId) {
		//list = this.list.stream().filter(e->e.getId()!=courseId).collect(Collectors.toList());
		Course entity =coursedao.getOne(courseId);
		coursedao.delete(entity);
		
	}
	

}
